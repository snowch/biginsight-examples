This plugin allows you to specify SQL statements to be executed
when you first connect to an alias.

A "Session Scripts" option is added to the plugins menu.